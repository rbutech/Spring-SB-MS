package beans;
//controller

public class A {
	
	public void create(String name,String email) {
		System.out.println("create method..");
		B b=new B();
		b.businessLogic(name, email);
	}

}
