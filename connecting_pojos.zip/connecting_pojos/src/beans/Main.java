package beans;

public class Main {
public static void main(String[] args) {
	
	A a=new A();
	a.create("naveen", "naveen@gmail.com");
	
	
}
}
