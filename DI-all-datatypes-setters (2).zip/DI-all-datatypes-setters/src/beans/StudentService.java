package beans;

public class StudentService implements IStudentService {
	public StudentService() {
	System.out.println("StudentService object");
	}
	
	public void serviceMethod() {
		System.out.println("serviceMethod..");
	}

}
