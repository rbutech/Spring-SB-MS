package beans;

public interface IStudentService {
	public void serviceMethod();
}
