package beans;

public class Company {
	String employeename = "SAI";
	int emplloyeeSalary = 56890;

	private Company() {
		System.out.println("Sai Company object");
		System.out.println(employeename);
		System.out.println(emplloyeeSalary);
	}

	public void noofEmp() {
		System.out.println("Company emp count 50000");
	}
}