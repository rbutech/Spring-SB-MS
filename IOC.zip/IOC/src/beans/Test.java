package beans;
public class Test{
private Test(){
System.out.println("Sreekanth");
}
public void testMethod() {
	System.out.println("my test method");
}
}