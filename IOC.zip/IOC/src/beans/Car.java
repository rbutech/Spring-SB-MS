package beans;

public class Car {
	private Car() {
		System.out.println("Adithya Car object created");
	}
	public void mycar() {
		System.out.println("audi car...");
	}
}