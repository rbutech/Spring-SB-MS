package beans;

public class User {
	private int id;

	private User() {
		System.out.println("Dixit User");

	}

	public void hello() {
		System.out.println("Hello method");
	}
}
