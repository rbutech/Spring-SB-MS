package beans;

public class Employee {
	private int eno;
	private String ename;
	private float esal;
	private String Eaddr;

	private Employee() {
		System.out.println("Employee Details Hrithik");
	}
	public void department() {
		System.out.println("software developper");
	}

}