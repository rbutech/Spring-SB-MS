package beans;

public class Bank {
	private String AccNo;
	private Bank() {
		System.out.println("Nazia Bank created successfully");
	}
	public void myaccout() {
		System.out.println("account balance 10000000000000");
	}
}