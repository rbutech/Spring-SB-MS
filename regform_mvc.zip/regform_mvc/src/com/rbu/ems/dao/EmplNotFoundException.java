package com.rbu.ems.dao;

public class EmplNotFoundException extends Exception {
	private String message;

	public EmplNotFoundException(String message) {
		super();
		this.message = message;
	}

	@Override
	public String toString() {
		return "EmplNotFoundException [message=" + message + "]";
	}

}
