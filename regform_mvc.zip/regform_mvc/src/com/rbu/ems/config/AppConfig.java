package com.rbu.ems.config;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.hibernate3.HibernateTemplate;

@Configuration
public class AppConfig {

	// integration happend here
	@Bean
	public SessionFactory createSessionfactory() {
		// org.hibernate.cfg.Configuration cfg=new org.hibernate.cfg.Configuration();
		AnnotationConfiguration cfg = new AnnotationConfiguration();
		cfg.configure("resources/oracle.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		return factory;

	}

	@Bean
	public HibernateTemplate createHibernateTemplate() {
		HibernateTemplate ht = new HibernateTemplate(createSessionfactory());
		return ht;
	}

}
