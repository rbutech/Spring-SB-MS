package com.rbu.ems.web;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.rbu.ems.dto.EmployeeDto;
import com.rbu.ems.service.EmployeService;

@Controller
public class RegController {
	@Autowired
	EmployeService employeService;

	@RequestMapping(value = "/student.rbu", method = RequestMethod.POST)
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String address = request.getParameter("address");
		String phone = request.getParameter("phone");
		String qual = request.getParameter("qual");
		EmployeeDto dto = employeService.createEmploye(
				EmployeeDto.builder().name(name).email(email).address(address).phone(phone).qual(qual).build());
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("msg", "Hello..... Mr/MS:" + name + " you successfully registered and your Id is:" + dto.getId());
		return new ModelAndView("success", map);// page name+ map(reqscope) object
	}

	@RequestMapping(value = "/student.rbu", method = RequestMethod.GET)
	public ModelAndView get(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Long id = Long.parseLong(request.getParameter("id"));
		EmployeeDto dto = employeService.findEmploye(EmployeeDto.builder().id(id).build());
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("msg", dto);
		return new ModelAndView("viewemp", map);// page name+ map(reqscope) object
	}

	@RequestMapping(value = "/findemp.rbu")
	public ModelAndView redirect() {
		return new ModelAndView("viewemp");
	}

}
