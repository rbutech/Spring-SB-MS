package com.rbu.car.service;

import com.rbu.car.dao.Fuel;

public class Engine {
	
	public void startEngine() {
		Fuel f=new Fuel();
		System.out.println("starting engine..");
		f.fireFuel();
	}
}
