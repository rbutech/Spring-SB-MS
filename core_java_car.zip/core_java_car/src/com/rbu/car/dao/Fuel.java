package com.rbu.car.dao;

public class Fuel {
	
public void fireFuel() {
	System.out.println("fuel started firing");
}

}
