package com.rbu.car.web;

import com.rbu.car.service.Engine;

public class Car {
	
	public void startCar(){
		Engine e=new Engine();//core java
		System.out.println("starting car....");
		e.startEngine();
	}

}
