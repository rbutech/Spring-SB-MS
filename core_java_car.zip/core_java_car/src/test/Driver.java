package test;

import com.rbu.car.web.Car;

public class Driver {
public static void main(String[] args) {
	
	//pushbutton to start
	System.out.println("driver calling start button");
	Car c=new Car();
	c.startCar();
	
	//Driver-Car-Engine-Fuel
	
	
}
}
