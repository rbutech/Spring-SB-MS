package beans;

public interface ITyre {
	String name();

	int size();

	String pattern();
}
