package com.rbu.ems.util;

import org.springframework.stereotype.Component;

@Component
public class MyUtil {
	public MyUtil() {
		System.out.println("MyUtil object created...");
	}

}
