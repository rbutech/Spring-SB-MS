package beans;

import org.springframework.beans.factory.annotation.Value;

public class Sim {
	@Value("${sim_provider}")
	private String simProvider;

	@Override
	public String toString() {
		return "Sim [simProvider=" + simProvider + "]";
	}

}
