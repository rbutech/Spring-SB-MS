package beans;

import java.util.Properties;

public class ApplicationProperties {
Properties properties;
public void setProperties(Properties properties) {
	this.properties = properties;
}
@Override
public String toString() {
	return "ApplicationProperties [properties=" + properties + "]";
}

}
