package beans;

public class EmployeeController {

	EmployeeController() {
			System.out.println("EmployeeController object...");
	}

}
