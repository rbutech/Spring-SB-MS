package com.rbu.estore.web;

public class OrderController {
	
	public OrderController() {
	System.out.println("OrderController object created.....");
	}

}
