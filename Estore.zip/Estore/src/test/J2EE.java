package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.rbu.estore.web.OrderController;

public class J2EE {
	public static void main(String[] args) {

		ApplicationContext factory = new ClassPathXmlApplicationContext("resources/spring.xml");

		// naveen want to order milk //never never allow to change object level parameters
		//end user can access only method level
		OrderController or1 = factory.getBean(OrderController.class);
		// dixit pen
		OrderController or2 = factory.getBean(OrderController.class);
		// akash book
		OrderController or3 = factory.getBean(OrderController.class);
		
		System.out.println(or1==or2);

		System.out.println(or1==or3);
	}
}
