package com.rbu.sms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class StudentDao {

	Connection con;

	public StudentDao() {
		System.out.println("StudentDao object");
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",
					"system", "admin");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int save(String name, String email, String address, String phone) throws SQLException {
		//dao get data from business
		Statement statement = con.createStatement();
		ResultSet rs = statement.executeQuery("select max(id) from STUDENT_SBMS");
		int id = 0;
		if (rs.next()) {
			id = rs.getInt(1);
		}
		id++;
		statement.executeUpdate(
				"insert into STUDENT_SBMS values("+id+",'" + name + "','" + email + "','" + address + "','" + phone + "')");
		
		return id;
	}

}
