package com.rbu.sms.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.rbu.sms.service.RegBusiness;

public class RegController extends HttpServlet {
	RegBusiness business = new RegBusiness();// ref for business
	public RegController() {
	System.out.println("RegController object");
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// controller get data from front end
		
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String address = req.getParameter("address");
		String phone = req.getParameter("phone");
		int id = 0;
		try {
			id = business.createStudent(name, email, address, phone);
		} catch (Exception e) {
			e.printStackTrace();
		}
		resp.getWriter().print("<p style='color:'green''>SUCECSS ID:"+id+"</p>");
	}

}
