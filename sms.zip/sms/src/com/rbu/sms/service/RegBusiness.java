package com.rbu.sms.service;

import java.sql.SQLException;

import com.rbu.sms.dao.StudentDao;

public class RegBusiness {
	StudentDao dao = new StudentDao();//dao ref

	public RegBusiness() {
		System.out.println("RegBusiness obejct");
	}

	public int createStudent(String name, String email, String address, String phone) throws SQLException {
		//business get data from controller
		int id = dao.save(name, email, address, phone);
		return id;
	}

}
