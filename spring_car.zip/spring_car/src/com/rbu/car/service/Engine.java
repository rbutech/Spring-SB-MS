package com.rbu.car.service;

import com.rbu.car.dao.Fuel;

public class Engine {
	Fuel fuel;
	public void setFuel(Fuel fuel) {
		System.out.println("setfuel method calling");
		this.fuel=fuel;
	}
	
	public void startEngine() {
		//Fuel f=new Fuel();
		System.out.println("starting engine..");
		fuel.fireFuel();
	}
}
