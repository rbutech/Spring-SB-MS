package com.rbu.car.web;

import com.rbu.car.service.Engine;

public class Car {
	Engine engine;
	
	public void setEngine(Engine engine) {
		System.out.println("setEngine method calling");
		this.engine=engine;		
	}
	public void startCar(){
		//Engine e=new Engine();//core java
		System.out.println("starting car....");
		engine.startEngine();
	}

}
