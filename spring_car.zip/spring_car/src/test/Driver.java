package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.rbu.car.web.Car;

public class Driver {
public static void main(String[] args) {
	
	//pushbutton to start
	//Car c=new Car();
	
	ApplicationContext ap=new ClassPathXmlApplicationContext("resources/spring.xml");
	System.out.println("driver calling start button");

	Car c=ap.getBean(Car.class);
	c.startCar();
	
	//Driver-Car-Engine-Fuel
	
	
}
}
