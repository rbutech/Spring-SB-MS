package beans;

import lombok.Setter;
import lombok.ToString;

//Frontend->controller(service),Service($APIurl,DAO)->Dao(db config)-DataBase
@Setter
@ToString
public class StudentController {
	// primitives
	private int roleno;
	private String name;
	private boolean active;
	// array type
	private String[] courses;
	
	public void useIt() {
		System.out.println(roleno);
		System.out.println(name);
		System.out.println(active);		
		for(String s:courses) {
			System.out.println(s);
		}
	}

}
