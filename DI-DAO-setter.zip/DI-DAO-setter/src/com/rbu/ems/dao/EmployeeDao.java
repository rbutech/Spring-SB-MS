package com.rbu.ems.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class EmployeeDao {
	public EmployeeDao() {
		System.out.println("EmployeeDao object created.....");
	}
	// with no DI
	public void createEmploye(int id, String name, String email, String address) {
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
			Statement statement = con.createStatement();
			statement.executeUpdate(
					"insert into EMPLOYEE_RBUEMP values(" + id + ",'" + name + "','" + email + "','" + address + "')");
			statement.close();
			con.close();
		} catch (Exception e) {
		}
		System.out.println("success : createEmployee");

	}
}
