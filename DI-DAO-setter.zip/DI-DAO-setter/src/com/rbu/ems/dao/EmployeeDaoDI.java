package com.rbu.ems.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class EmployeeDaoDI {
	public EmployeeDaoDI() {
		System.out.println("EmployeeDaoDI object created.....");
	}

	String driver;
	String url;
	String username;
	String password;

	public void setDriver(String driver) {
		System.out.println("setDriver injected");
		this.driver = driver;
	}

	public void setUrl(String url) {
		System.out.println("setUrl injected");
		this.url = url;
	}

	public void setUsername(String username) {
		System.out.println("setUsername injected");
		this.username = username;
	}

	public void setPassword(String password) {
		System.out.println("setPassword injected");
		this.password = password;
	}

	// with DI
	public void createEmploye(int id, String name, String email, String address) {
		try {
			Class.forName(driver);//xml input will come here
			Connection con = DriverManager.getConnection(url,username , password);//xml input will come here
			Statement statement = con.createStatement();
			statement.executeUpdate(
					"insert into EMPLOYEE_RBUEMP values(" + id + ",'" + name + "','" + email + "','" + address + "')");
			statement.close();
			con.close();
		} catch (Exception e) {
		}
		System.out.println("success : createEmployee");

	}
}
